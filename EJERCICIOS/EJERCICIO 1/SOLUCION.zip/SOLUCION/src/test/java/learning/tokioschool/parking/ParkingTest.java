package learning.tokioschool.parking;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

// TODO: Auto-generated Javadoc
/**
 * The Class ParkingTest.
 * @author Alexander Silvera
 */
class ParkingTest {

	/** The parking imprimir. */
	private static Parking parking, parkingImprimir;
	
	/** The matricula. */
	private static String matricula;
	
	/** The coche imprimir. */
	private static Coche coche, cocheImprimir;
	
	/** The a pagar. */
	private static float aPagar;

	/**
	 * Inicializa.
	 */
	@BeforeAll
	public static void inicializa() {
		System.out.println("Comenzando tests");
		matricula = "ASF2309";
		int minutos = 120;
		parking = new Parking();
		coche = new Coche("Ford", "Mustan", LocalDateTime.now(), LocalDateTime.now().plusMinutes(minutos));
		parking.putCoche(matricula, coche);
		parkingImprimir = new Parking();
		cocheImprimir = new Coche("Ford", "Mustan", LocalDateTime.of(2025, 1, 15, 10, 00), null);
		parkingImprimir.putCoche(matricula, cocheImprimir);
		aPagar = 0.15f * minutos;
	}

	/**
	 * Limpia sistema.
	 */
	@AfterAll
	public static void limpiaSistema() {
		coche = null;
		parking = null;
		cocheImprimir = null;
		parkingImprimir = null;
		System.gc();
		System.out.println("Tests Finalizados");
	}

	/**
	 * Prueba unitaria para el método {@code putCoche} de la clase {@code Parking}.
	 * <p>
	 * Verifica que:
	 * <ul>
	 *   <li>El coche añadido al sistema existe en el mapa del parking.</li>
	 *   <li>El coche recuperado mediante la matrícula es igual al objeto esperado.</li>
	 * </ul>
	 */
	@Test
	void testPutCoche() {
		assertTrue(parking.existeCoche(matricula));
		assertEquals(coche, parking.getCoche(matricula));
	}

	/**
	 * Prueba unitaria para el método {@code existeCoche} de la clase {@code Parking}.
	 * <p>
	 * Verifica el comportamiento del método {@code existeCoche} en dos escenarios:
	 * <ul>
	 *   <li>El coche con una matrícula existente en el sistema es reconocido como existente.</li>
	 *   <li>Una matrícula inexistente no es reconocida como existente en el sistema.</li>
	 * </ul>
	 */
	@Test
	void testExisteCoche() {
		assertTrue(parking.existeCoche(matricula));
		assertFalse(parking.existeCoche("AFS1234"));
	}

	/**
	 * Prueba unitaria para el método {@code getCoche} de la clase {@code Parking}.
	 * <p>
	 * Verifica que el método {@code getCoche} devuelve correctamente el objeto {@code Coche}
	 * asociado a una matrícula existente en el sistema y que no devuelve un objeto incorrecto
	 * para una matrícula inexistente.
	 */
	@Test
	void testGetCoche() {
		assertEquals(coche, parking.getCoche(matricula));
		assertNotEquals(coche, parking.getCoche("AFS1234"));
	}

	/**
	 * Prueba unitaria para el método {@code imprimirCochesSistema} de la clase {@code Parking}.
	 * <p>
	 * Verifica que el método {@code imprimirCochesSistema} genera correctamente la salida en consola
	 * para los coches registrados en el sistema.
	 * <p>
	 * En este caso, la prueba captura la salida en consola generada por el método y comprueba que
	 * contiene la información esperada para un coche previamente registrado.
	 */
	@Test
	void testImprimirCochesSistema() {
		String mjsConsola = LeerConsola.leerConsola(() -> parkingImprimir.imprimirCochesSistema());
		assertTrue(mjsConsola.contains("Matricula: ASF2309 Datos del Coche [marca=Ford, modelo=Mustan, horaEntrada=2025-01-15T10:00, horaSalida=null]"));
	}

	/**
	 * Prueba unitaria para el método {@code imprimirCochesParking} de la clase {@code Parking}.
	 * <p>
	 * Verifica que el método {@code imprimirCochesParking} genera correctamente la salida en consola
	 * para los coches actualmente estacionados (con {@code horaSalida == null}).
	 * <p>
	 * También valida que el método maneje adecuadamente una excepción generada al intentar procesar
	 * un coche nulo y que emita el mensaje de error correspondiente.
	 */
	@Test
	void testImprimirCochesParking() {
		String mjsConsola = LeerConsola.leerConsola(() -> parkingImprimir.imprimirCochesParking()); 
        assertTrue(mjsConsola.contains("Matricula: ASF2309 Datos del Coche [marca=Ford, modelo=Mustan, horaEntrada=2025-01-15T10:00, horaSalida=null]"));
        parkingImprimir.putCoche("JLK1594", null);
	    String mjsConsolaNull = LeerConsola.leerConsola(() -> parkingImprimir.imprimirCochesParking());
	    assertTrue(mjsConsolaNull.contains("Error al imprimir coches en el parking"));
	}

	/**
	 * Prueba unitaria para el método {@code cantidadAPagar} de la clase {@code Parking}.
	 * <p>
	 * Esta prueba verifica los siguientes escenarios:
	 * <ul>
	 *   <li>El manejo correcto de una matrícula nula, donde se espera que se lance una {@code NullPointerException}.</li>
	 *   <li>La correcta ejecución del cálculo del monto a pagar para un coche estacionado en el sistema.</li>
	 *   <li>La validación de la salida generada en consola para el cálculo de la cantidad a pagar.</li>
	 * </ul>
	 */
	@Test
	void testCantidadAPagar() {
		//Matricula null
		assertThrows(NullPointerException.class, () -> assertNotEquals(aPagar, parking.getCoche(null).cantidadAPagar(), 0.001));		
		
		assertEquals(aPagar, parking.getCoche(matricula).cantidadAPagar(), 0.001, "Cálculo incorrecto");
		String mjsConsola = LeerConsola.leerConsola(() -> parking.cantidadAPagar(matricula)); 
		assertTrue(mjsConsola.contains("Cantidad a pagar 18.0"));
		//parking.cantidadAPagar(matricula);		
	}
}
