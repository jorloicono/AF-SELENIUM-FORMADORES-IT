package learning.tokioschool.parking;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

// TODO: Auto-generated Javadoc
/**
 * The Class CocheTest.
 * @author Alexander Silvera
 */
class CocheTest {

	/** The coche to string. */
	private static Coche coche, cocheToString;
	
	/** The a pagar. */
	private static float aPagar;

	/**
	 * Inicializa.
	 */
	@BeforeAll
	public static void inicializa() {
		System.out.println("Comenzando tests");
		int minutos = 100;
		coche = new Coche("Ford", "Mustang", LocalDateTime.now(), LocalDateTime.now().plusMinutes(minutos));
		cocheToString = new Coche("Ford", "Mustang", LocalDateTime.of(2025, 1, 15, 10, 00),LocalDateTime.of(2025, 1, 15, 12, 00));
		aPagar = 0.15f * minutos; 
	}

	/**
	 * Limpia sistema.
	 */
	@AfterAll
	public static void limpiaSistema() {
		coche = null;
		cocheToString = null;
		System.gc(); 
		System.out.println("Tests Finalizados");
	}

	/**
	 * Prueba unitaria para el método {@code cantidadAPagar} de la clase {@code Coche}.
	 * <p>
	 * Esta prueba verifica los siguientes escenarios:
	 * <ul>
	 *   <li>El cálculo correcto de la cantidad a pagar para un coche con datos de entrada y salida válidos.</li>
	 *   <li>La validación de que el cálculo es diferente para coches con distintos tiempos de permanencia.</li>
	 * </ul>
	 */
	@Test
	public void testCantidadAPagar() {
		assertEquals(aPagar, coche.cantidadAPagar(), 0.001, "Cálculo incorrecto");
		assertNotEquals(aPagar, new Coche("Ford", "Mustang", LocalDateTime.now(), LocalDateTime.now().minusMinutes(100)).cantidadAPagar());
	}

	/**
	 * Prueba unitaria para el método {@code toString} de la clase {@code Coche}.
	 * <p>
	 * Esta prueba verifica que la representación en forma de cadena de un objeto {@code Coche}
	 * sea igual a la salida esperada, basada en los valores de sus atributos.
	 */
	@Test
	public void testToString() {
		// System.out.println(cocheToString.toString());
		assertEquals("Coche [marca=Ford, modelo=Mustan, horaEntrada=2025-01-15T10:00, horaSalida=2025-01-15T12:00]",
				cocheToString.toString());
	}
}
