package learning.tokioschool.parking;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

// TODO: Auto-generated Javadoc
/**
 * The Class LeerConsola.
 * @author Alexander Silvera
 */
public class LeerConsola {
	
	/**
	 * Captura la salida estándar generada por un bloque de código ejecutado.
	 * <p>
	 * Este método redirige temporalmente la salida estándar ({@code System.out}) a un flujo
	 * de datos en memoria, ejecuta el código proporcionado como {@link Runnable}, y devuelve
	 * el contenido impreso como una cadena. En caso de que se lance una excepción {@link NullPointerException},
	 * se captura y se muestra un mensaje de error.
	 * </p>
	 *
	 * @param runnable el bloque de código que genera salida estándar y debe ser capturado.
	 * @return una cadena que contiene la salida estándar generada durante la ejecución del bloque.
	 * @throws NullPointerException si el parámetro {@code runnable} es {@code null}.
	 */
	public static String leerConsola(Runnable runnable) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream original = System.out;
		try (PrintStream capture = new PrintStream(baos)) {
			System.setOut(capture);
			runnable.run();			
		} 
		catch (NullPointerException  npe) {
			System.out.println("Error");
			}
		finally {
			System.setOut(original);
		}
		return baos.toString();		
	}
}
